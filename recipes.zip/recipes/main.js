import { recipes } from "./recipes.mjs";

console.log("Recipe data loaded:", recipes);
