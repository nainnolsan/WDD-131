export const recipes = [
  {
    name: "Apple Crisp",
    tags: ["dessert"],
    rating: 4,
    description:
      "This apple crisp recipe is a simple yet delicious fall dessert that’s great served warm with vanilla ice cream.",
    image: "images/apple-crisp.jpg",
  },
  {
    name: "Chocolate Brownies",
    tags: ["dessert", "chocolate"],
    rating: 5,
    description:
      "Rich, fudgy brownies with a crackly top and deep chocolate flavor. Perfect for any chocolate lover!",
    image: "images/chocolate-brownie.jpg",
  },
  {
    name: "Chicken Tacos",
    tags: ["dinner", "mexican"],
    rating: 5,
    description:
      "Juicy grilled chicken wrapped in warm tortillas, topped with fresh cilantro, onions, and a squeeze of lime.",
    image: "images/chicken-tacos.jpg",
  },
];
